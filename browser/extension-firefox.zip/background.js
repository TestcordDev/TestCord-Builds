/**
 * @template T
 * @param {T[]} arr
 * @param {(v: T) => boolean} predicate
 */
function removeFirst(arr, predicate) {
    const idx = arr.findIndex(predicate);
    if (idx !== -1) arr.splice(idx, 1);
}

chrome.webRequest.onHeadersReceived.addListener(
    ({ responseHeaders, type, url }) => {
        if (!responseHeaders) return;

        if (type === "main_frame" && url.includes("discord.com")) {
            // In main frame requests, the CSP needs to be removed to enable fetching of custom css
            // as desired by the user
            removeFirst(responseHeaders, h => h.name.toLowerCase() === "content-security-policy");
        } else if (type === "stylesheet" && url.startsWith("https://raw.githubusercontent.com/")) {
            // Most users will load css from GitHub, but GitHub doesn't set the correct content type,
            // so we fix it here
            removeFirst(responseHeaders, h => h.name.toLowerCase() === "content-type");
            responseHeaders.push({
                name: "Content-Type",
                value: "text/css"
            });
        }
        return { responseHeaders };
    },
    { urls: ["https://raw.githubusercontent.com/*", "*://*.discord.com/*"], types: ["main_frame", "stylesheet"] },
    ["blocking", "responseHeaders"]
);

// Inject CORS headers for AI API domains so plugins can fetch from the renderer without CORS errors
chrome.webRequest.onHeadersReceived.addListener(
    ({ responseHeaders }) => {
        if (!responseHeaders) return;
        responseHeaders.push({
            name: "Access-Control-Allow-Origin",
            value: "*"
        }, {
            name: "Access-Control-Allow-Headers",
            value: "*"
        }, {
            name: "Access-Control-Allow-Methods",
            value: "GET, POST, PUT, DELETE, OPTIONS"
        });
        return { responseHeaders };
    },
    {
        urls: ["https://api.groq.com/*", "https://api.openai.com/*", "https://api.cord.cat/*", "https://geoseeer.com/*"],
        types: ["xmlhttprequest"]
    },
    ["blocking", "responseHeaders"]
);

// CordCat answers every request that carries an Origin header with a 500, which makes it
// unreachable from a browser even with CORS headers injected above. Drop the header on the way out.
chrome.webRequest.onBeforeSendHeaders.addListener(
    ({ requestHeaders }) => ({
        requestHeaders: (requestHeaders || []).filter(h => h.name.toLowerCase() !== "origin")
    }),
    { urls: ["https://api.cord.cat/*"], types: ["xmlhttprequest"] },
    ["blocking", "requestHeaders"]
);
